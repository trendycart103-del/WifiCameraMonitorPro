# WiFi & Camera Monitor Pro

Build: push to GitHub, open the Actions tab, download the debug-apk artifact.

Use only on networks and cameras you own or are authorized to test.

Passive Wi-Fi data per access point (from the official ScanResult API): SSID, BSSID, vendor (OUI sample), signal, estimated distance,
security + grade, key management, ciphers, PMF, WPS, Wi-Fi standard, band, frequency, channel, width, center frequencies,
Passpoint, 802.11mc, operator/venue, beacon age, location, scan time and an automatic audit.
Android does not expose raw 802.11 frames or full information elements to normal apps.
