# WiFi & Camera Monitor Pro

Two pages: Scanner (auto temporary save of all Wi-Fi networks, save any to permanent, full data per network) and Cameras (cameras on your connected network, viewer with play/pause/rewind/forward/zoom).

Build: push to GitHub, open the Actions tab, download the debug-apk artifact.

Use only on networks and cameras you own or are authorized to test.
