package com.wcm.pro
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Neon {
    val Bg = Color(0xFF070B1A); val Bg2 = Color(0xFF111833); val Card = Color(0xFF151C3A)
    val Cyan = Color(0xFF22E5FF); val Violet = Color(0xFF9B6BFF); val Magenta = Color(0xFFFF4FD8)
    val Green = Color(0xFF3DFFA2); val Amber = Color(0xFFFFC53D); val Red = Color(0xFFFF4D6D)
    val Text = Color(0xFFEAF0FF); val Dim = Color(0xFF8A94B8)
    val bgBrush = Brush.verticalGradient(listOf(Bg, Bg2, Color(0xFF1A1040)))
}

fun signalColor(percent: Int): Color = when { percent >= 70 -> Neon.Green; percent >= 45 -> Neon.Amber; else -> Neon.Red }
fun gradeColor(g: String): Color = when (g) { "A" -> Neon.Green; "B+", "B" -> Neon.Cyan; "C" -> Neon.Amber; else -> Neon.Red }

@Composable fun ProTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(primary = Neon.Cyan, secondary = Neon.Violet, tertiary = Neon.Magenta, background = Neon.Bg, surface = Neon.Card, onSurface = Neon.Text, onBackground = Neon.Text)
    val type = Typography(
        titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 0.5.sp),
        titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 17.sp),
        bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp),
        bodySmall = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
        labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, letterSpacing = 1.sp))
    MaterialTheme(colorScheme = scheme, typography = type, content = content)
}

@Composable fun GlowCard(accent: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Neon.Card, Neon.Bg2)))
        .border(1.dp, Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.15f))), RoundedCornerShape(18.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
}

@Composable fun Chip(text: String, color: Color) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.18f)).border(1.dp, color, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 3.dp)) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

@Composable fun NeonButton(text: String, icon: ImageVector, color: Color, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(14.dp)).background(Brush.horizontalGradient(listOf(color.copy(alpha = if (enabled) 0.9f else 0.3f), color.copy(alpha = 0.45f))))
        .clickable(enabled = enabled) { onClick() }.padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Neon.Bg, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
        Text(text, color = Neon.Bg, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
}

@Composable fun IconTextButton(text: String, icon: ImageVector, color: Color, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(10.dp)).clickable { onClick() }.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = color, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable fun RoundIcon(icon: ImageVector, color: Color, big: Boolean = false, onClick: () -> Unit) {
    val s = if (big) 68.dp else 52.dp
    Box(Modifier.size(s).clip(CircleShape).background(color.copy(alpha = 0.15f)).border(2.dp, color, CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = color, modifier = Modifier.size(if (big) 36.dp else 26.dp)) }
}

@Composable fun NeonField(value: String, onChange: (String) -> Unit, label: String, icon: ImageVector, modifier: Modifier = Modifier, password: Boolean = false) {
    OutlinedTextField(value, onChange, label = { Text(label) }, leadingIcon = { Icon(icon, null, tint = Neon.Cyan) }, singleLine = true, modifier = modifier.fillMaxWidth(),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Neon.Cyan, unfocusedBorderColor = Neon.Dim, focusedLabelColor = Neon.Cyan, unfocusedLabelColor = Neon.Dim, focusedTextColor = Neon.Text, unfocusedTextColor = Neon.Text))
}
