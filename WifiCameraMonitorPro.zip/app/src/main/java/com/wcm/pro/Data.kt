package com.wcm.pro
import android.content.Context
import androidx.room.*
import androidx.work.*
import kotlinx.coroutines.flow.Flow
import java.util.concurrent.TimeUnit

@Entity(tableName = "wifi", indices = [Index("bssid"), Index("permanent")])
data class WifiRec(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ssid: String, val bssid: String, val level: Int, val percent: Int,
    val security: String, val frequency: Int, val channel: Int, val width: String,
    val scanTime: Long, val lat: Double? = null, val lon: Double? = null,
    val permanent: Boolean = false, val note: String = "",
    // extended passive data (all from the official ScanResult API, "N/A" when unavailable)
    val capabilities: String = "N/A", val vendor: String = "N/A", val standard: String = "N/A",
    val centerFreq0: Int = 0, val centerFreq1: Int = 0, val wps: String = "N/A", val pmf: String = "N/A",
    val akm: String = "N/A", val cipher: String = "N/A", val isPasspoint: String = "N/A",
    val is80211mc: String = "N/A", val ageMs: Long = -1, val operatorName: String = "N/A",
    val venueName: String = "N/A", val infoElements: String = "N/A", val risk: String = "N/A",
    val distanceM: Double = -1.0
)

@Entity(tableName = "camera")
data class CameraRec(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val ip: String, val port: Int = 554, val protocol: String = "rtsp",
    val username: String = "", val password: String = "", val path: String = "", val status: String = "Unknown"
)

data class Hist(val t: Long, val n: Int)

@Dao interface AppDao {
    @Query("SELECT * FROM wifi WHERE permanent=:perm AND (ssid LIKE '%'||:q||'%' OR bssid LIKE '%'||:q||'%' OR security LIKE '%'||:q||'%' OR vendor LIKE '%'||:q||'%') ORDER BY scanTime DESC")
    fun wifi(perm: Boolean, q: String): Flow<List<WifiRec>>
    @Query("SELECT * FROM wifi") suspend fun allWifi(): List<WifiRec>
    @Query("SELECT * FROM wifi WHERE permanent=1") suspend fun permWifi(): List<WifiRec>
    @Query("SELECT * FROM wifi WHERE bssid=:b ORDER BY scanTime DESC") fun byBssid(b: String): Flow<List<WifiRec>>
    @Query("SELECT * FROM wifi WHERE permanent=1 AND bssid=:b LIMIT 1") suspend fun savedByBssid(b: String): WifiRec?
    @Query("SELECT * FROM wifi WHERE id IN (:ids)") suspend fun byIds(ids: List<Long>): List<WifiRec>
    @Insert suspend fun insertWifi(w: List<WifiRec>)
    @Update suspend fun updateWifi(w: WifiRec)
    @Query("DELETE FROM wifi WHERE id=:id") suspend fun deleteWifi(id: Long)
    @Query("DELETE FROM wifi WHERE permanent=0 AND scanTime<:cutoff") suspend fun purge(cutoff: Long)
    @Query("DELETE FROM wifi") suspend fun clearWifi()
    @Query("SELECT scanTime AS t, COUNT(*) AS n FROM wifi WHERE permanent=0 GROUP BY scanTime ORDER BY scanTime DESC") fun history(): Flow<List<Hist>>
    @Query("SELECT * FROM wifi WHERE permanent=0 AND scanTime=:t ORDER BY level DESC") fun scanAt(t: Long): Flow<List<WifiRec>>
    @Query("SELECT * FROM wifi WHERE permanent=0 AND scanTime=:t") fun byScan(t: Long): Flow<List<WifiRec>>
    @Query("SELECT COUNT(*) FROM wifi WHERE permanent=:p") fun count(p: Boolean): Flow<Int>

    @Query("SELECT * FROM camera") fun cameras(): Flow<List<CameraRec>>
    @Query("SELECT * FROM camera") suspend fun allCameras(): List<CameraRec>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertCamera(c: CameraRec)
    @Query("DELETE FROM camera WHERE id=:id") suspend fun deleteCamera(id: Long)
    @Query("DELETE FROM camera") suspend fun clearCameras()
}

@Database(entities = [WifiRec::class, CameraRec::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var i: AppDb? = null
        fun get(c: Context): AppDb = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "wcm.db")
                .fallbackToDestructiveMigration().build().also { i = it }
        }
    }
}

class CleanupWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        AppDb.get(applicationContext).dao().purge(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(30))
        return Result.success()
    }
    companion object {
        fun schedule(c: Context) {
            WorkManager.getInstance(c).enqueueUniquePeriodicWork(
                "cleanup", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<CleanupWorker>(1, TimeUnit.DAYS).build())
        }
    }
}
