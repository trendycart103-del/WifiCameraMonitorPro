package com.wcm.pro
import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.pow

object Scanner {
    // Small built-in sample of well-known OUI prefixes (first 3 bytes of the BSSID). Unknown -> "N/A".
    private val OUI = mapOf(
        "00:1A:11" to "Google", "3C:5A:B4" to "Google", "F4:F5:D8" to "Google",
        "00:17:F2" to "Apple", "A4:83:E7" to "Apple", "F0:18:98" to "Apple",
        "00:12:FB" to "Samsung", "5C:0A:5B" to "Samsung", "E8:50:8B" to "Samsung",
        "00:1D:7E" to "Cisco-Linksys", "00:14:BF" to "Cisco-Linksys", "00:0C:41" to "Cisco-Linksys",
        "00:1F:33" to "Netgear", "A0:63:91" to "Netgear", "20:E5:2A" to "Netgear",
        "00:1B:11" to "D-Link", "14:D6:4D" to "D-Link", "1C:7E:E5" to "D-Link",
        "00:1D:0F" to "TP-Link", "50:C7:BF" to "TP-Link", "98:DA:C4" to "TP-Link", "F4:F2:6D" to "TP-Link",
        "00:0F:B5" to "Netgear", "00:25:9C" to "Cisco", "00:1E:58" to "D-Link",
        "00:E0:4C" to "Realtek", "00:0C:43" to "Ralink/MediaTek", "00:26:5A" to "D-Link",
        "BC:AE:C5" to "ASUSTek", "00:1A:92" to "ASUSTek", "04:D4:C4" to "ASUSTek", "2C:56:DC" to "ASUSTek",
        "00:25:00" to "Apple", "28:6C:07" to "Xiaomi", "64:09:80" to "Xiaomi", "78:11:DC" to "Xiaomi",
        "00:90:4C" to "Epigram/Broadcom", "00:10:18" to "Broadcom", "E0:CB:4E" to "ASUSTek",
        "48:8F:5A" to "Huawei", "00:E0:FC" to "Huawei", "70:72:CF" to "Huawei", "C8:3A:35" to "Tenda",
        "B0:95:75" to "Ubiquiti", "24:A4:3C" to "Ubiquiti", "DC:9F:DB" to "Ubiquiti", "FC:EC:DA" to "Ubiquiti",
        "00:50:56" to "VMware", "08:00:27" to "VirtualBox", "B8:27:EB" to "Raspberry Pi", "DC:A6:32" to "Raspberry Pi"
    )

    fun vendor(bssid: String): String {
        if (bssid.length < 8) return "N/A"
        val p = bssid.substring(0, 8).uppercase()
        val first = p.substring(0, 2).toIntOrNull(16) ?: return "N/A"
        if (first and 2 != 0) return "N/A (randomized / locally administered MAC)"
        return OUI[p] ?: "N/A"
    }

    @SuppressLint("MissingPermission")
    fun scan(c: Context, lat: Double?, lon: Double?): List<WifiRec> {
        val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION") wm.startScan()  // Android throttles scans; results may be cached
        val now = System.currentTimeMillis()
        val list = try { wm.scanResults } catch (e: SecurityException) { emptyList() }
        return list.map { r -> build(r, now, lat, lon) }
    }

    @SuppressLint("NewApi")
    private fun build(r: ScanResult, now: Long, lat: Double?, lon: Double?): WifiRec {
        val cap = r.capabilities ?: ""
        val sdk = Build.VERSION.SDK_INT
        val std = if (sdk >= 30) when (r.wifiStandard) {
            ScanResult.WIFI_STANDARD_LEGACY -> "802.11a/b/g"; ScanResult.WIFI_STANDARD_11N -> "Wi-Fi 4 (802.11n)"
            ScanResult.WIFI_STANDARD_11AC -> "Wi-Fi 5 (802.11ac)"; ScanResult.WIFI_STANDARD_11AX -> "Wi-Fi 6 (802.11ax)"
            8 -> "Wi-Fi 7 (802.11be)"; else -> "N/A" } else "N/A"
        val ssid: String? = if (sdk >= 33) (r.wifiSsid?.toString()?.trim('"') ?: r.SSID) else r.SSID
        val bssid = r.BSSID ?: "N/A"
        val rec = WifiRec(
            ssid = if (ssid.isNullOrBlank()) "N/A (hidden)" else ssid, bssid = bssid,
            level = r.level, percent = WifiManager.calculateSignalLevel(r.level, 101),
            security = security(cap), frequency = r.frequency, channel = channel(r.frequency),
            width = width(r), scanTime = now, lat = lat, lon = lon,
            capabilities = cap.ifBlank { "N/A" }, vendor = vendor(bssid), standard = std,
            centerFreq0 = if (sdk >= 23) r.centerFreq0 else 0, centerFreq1 = if (sdk >= 23) r.centerFreq1 else 0,
            wps = if ("WPS" in cap) "Enabled (advertised)" else "Not advertised",
            pmf = pmf(cap), akm = akm(cap), cipher = cipher(cap),
            isPasspoint = if (sdk >= 23) (if (r.isPasspointNetwork) "Yes" else "No") else "N/A",
            is80211mc = if (sdk >= 23) (if (r.is80211mcResponder) "Yes" else "No") else "N/A",
            ageMs = if (sdk >= 17) (android.os.SystemClock.elapsedRealtime() - r.timestamp / 1000) else -1,
            operatorName = if (sdk >= 23) (r.operatorFriendlyName?.toString() ?: "N/A") else "N/A",
            venueName = if (sdk >= 23) (r.venueName?.toString()?.ifBlank { null } ?: "N/A") else "N/A",
            infoElements = if (sdk >= 30) "${r.informationElements?.size ?: 0} elements" else "N/A",
            distanceM = distance(r.level, r.frequency)
        )
        return rec.copy(risk = risk(rec))
    }

    fun channel(f: Int): Int = when {
        f == 2484 -> 14
        f in 2412..2472 -> (f - 2407) / 5
        f in 5000..5900 -> (f - 5000) / 5
        f in 5955..7115 -> (f - 5950) / 5
        else -> -1
    }

    fun band(f: Int): String = when {
        f in 2400..2500 -> "2.4 GHz"; f in 4900..5900 -> "5 GHz"; f in 5925..7125 -> "6 GHz"; else -> "N/A" }

    fun security(cap: String): String = when {
        "SAE" in cap && ("PSK" in cap) -> "WPA2/WPA3 (transition)"
        "SAE" in cap -> "WPA3"
        "OWE" in cap -> "Enhanced Open (OWE)"
        "EAP" in cap && "WPA2" in cap -> "WPA2-Enterprise"
        "EAP" in cap -> "WPA-Enterprise"
        "WPA2" in cap && "WPA-" in cap -> "WPA/WPA2 (mixed)"
        "WPA2" in cap -> "WPA2"
        "WPA" in cap -> "WPA (weak)"
        "WEP" in cap -> "WEP (weak)"
        cap.isNotBlank() -> "Open"
        else -> "N/A"
    }

    private fun pmf(cap: String) = when {
        "MFPR" in cap -> "Required"; "MFPC" in cap -> "Capable"; cap.isBlank() -> "N/A"; else -> "Not advertised" }

    private fun akm(cap: String): String {
        val l = mutableListOf<String>()
        if ("SAE" in cap) l += "SAE"; if ("PSK" in cap) l += "PSK"; if ("EAP" in cap) l += "802.1X/EAP"
        if ("OWE" in cap) l += "OWE"; if ("FT/" in cap) l += "FT (fast roaming)"; if ("SUITE_B" in cap) l += "Suite-B"
        return if (l.isEmpty()) "N/A" else l.joinToString(", ")
    }

    private fun cipher(cap: String): String {
        val l = mutableListOf<String>()
        if ("CCMP" in cap) l += "CCMP (AES)"; if ("GCMP" in cap) l += "GCMP"; if ("TKIP" in cap) l += "TKIP (weak)"
        if ("WEP" in cap) l += "WEP (weak)"
        return if (l.isEmpty()) "N/A" else l.joinToString(", ")
    }

    @SuppressLint("NewApi")
    fun width(r: ScanResult): String = when (r.channelWidth) {
        ScanResult.CHANNEL_WIDTH_20MHZ -> "20 MHz"; ScanResult.CHANNEL_WIDTH_40MHZ -> "40 MHz"
        ScanResult.CHANNEL_WIDTH_80MHZ -> "80 MHz"; ScanResult.CHANNEL_WIDTH_160MHZ -> "160 MHz"
        ScanResult.CHANNEL_WIDTH_80MHZ_PLUS_MHZ -> "80+80 MHz"
        else -> "N/A"
    }

    /** Free-space path-loss estimate. Rough only: walls and antennas change the real value. */
    fun distance(rssi: Int, mhz: Int): Double =
        if (mhz <= 0) -1.0 else 10.0.pow((27.55 - 20 * Math.log10(mhz.toDouble()) + Math.abs(rssi)) / 20.0)

    /** Simple defensive audit of what the AP advertises. */
    fun risk(w: WifiRec): String {
        val issues = mutableListOf<String>()
        val s = w.security
        if (s == "Open") issues += "Open network: traffic is unencrypted"
        if (s.startsWith("WEP")) issues += "WEP is broken, replace it"
        if (s.startsWith("WPA (weak)")) issues += "WPA1/TKIP is outdated"
        if ("TKIP" in w.cipher) issues += "TKIP cipher is weak"
        if (w.wps.startsWith("Enabled")) issues += "WPS advertised: disable it if unused"
        if ((s == "WPA2" || s.startsWith("WPA/")) && w.pmf == "Not advertised") issues += "No PMF: management frames unprotected"
        if (w.ssid.startsWith("N/A")) issues += "Hidden SSID (does not add real security)"
        return if (issues.isEmpty()) "No obvious issues" else issues.joinToString("; ")
    }

    fun grade(w: WifiRec): String {
        val s = w.security
        return when {
            s == "WPA3" || s == "WPA2-Enterprise" || s == "Enhanced Open (OWE)" -> "A"
            s.startsWith("WPA2/WPA3") -> "B+"
            s == "WPA2" && w.wps.startsWith("Not") -> "B"
            s == "WPA2" -> "C"
            s == "Open" || s.startsWith("WEP") || s.startsWith("WPA (weak)") -> "F"
            else -> "C"
        }
    }

    /** All data we hold about one access point, as readable text. */
    fun report(w: WifiRec, fmt: (Long) -> String): String = buildString {
        appendLine("SSID: ${w.ssid}"); appendLine("BSSID: ${w.bssid}"); appendLine("Vendor (OUI): ${w.vendor}")
        appendLine("Signal: ${w.level} dBm (${w.percent}%)"); appendLine("Approx. distance: ${if (w.distanceM >= 0) "%.1f m (estimate)".format(w.distanceM) else "N/A"}")
        appendLine("Security: ${w.security}   Grade: ${grade(w)}"); appendLine("Auth/Key mgmt: ${w.akm}"); appendLine("Cipher: ${w.cipher}")
        appendLine("PMF (802.11w): ${w.pmf}"); appendLine("WPS: ${w.wps}"); appendLine("Capabilities: ${w.capabilities}")
        appendLine("Standard: ${w.standard}"); appendLine("Band: ${band(w.frequency)}"); appendLine("Frequency: ${w.frequency} MHz")
        appendLine("Channel: ${w.channel}"); appendLine("Width: ${w.width}")
        appendLine("Center freq 0/1: ${if (w.centerFreq0 > 0) w.centerFreq0 else "N/A"} / ${if (w.centerFreq1 > 0) w.centerFreq1 else "N/A"}")
        appendLine("Passpoint: ${w.isPasspoint}"); appendLine("802.11mc (RTT): ${w.is80211mc}")
        appendLine("Operator: ${w.operatorName}"); appendLine("Venue: ${w.venueName}"); appendLine("Info elements: ${w.infoElements}")
        appendLine("Beacon age: ${if (w.ageMs >= 0) "${w.ageMs} ms" else "N/A"}")
        appendLine("Location: ${if (w.lat != null) "${w.lat}, ${w.lon}" else "N/A"}")
        appendLine("Scan time: ${fmt(w.scanTime)}"); appendLine("Audit: ${w.risk}")
        if (w.note.isNotBlank()) appendLine("Note: ${w.note}")
    }

    fun congestion(list: List<WifiRec>) = list.filter { it.channel > 0 }.groupingBy { it.channel }.eachCount().toSortedMap()

    /** Channel overlap score per 2.4 GHz channel (1/6/11 are the clean ones). */
    fun bestChannel24(list: List<WifiRec>): Int {
        val l = list.filter { it.frequency in 2400..2500 }
        return listOf(1, 6, 11).minByOrNull { ch -> l.count { Math.abs(it.channel - ch) < 5 } } ?: 1
    }

    private fun wj(it: WifiRec) = JSONObject().put("ssid", it.ssid).put("bssid", it.bssid).put("level", it.level)
        .put("percent", it.percent).put("security", it.security).put("frequency", it.frequency)
        .put("channel", it.channel).put("width", it.width).put("scanTime", it.scanTime)
        .put("lat", it.lat ?: JSONObject.NULL).put("lon", it.lon ?: JSONObject.NULL)
        .put("permanent", it.permanent).put("note", it.note).put("capabilities", it.capabilities)
        .put("vendor", it.vendor).put("standard", it.standard).put("centerFreq0", it.centerFreq0)
        .put("centerFreq1", it.centerFreq1).put("wps", it.wps).put("pmf", it.pmf).put("akm", it.akm)
        .put("cipher", it.cipher).put("isPasspoint", it.isPasspoint).put("is80211mc", it.is80211mc)
        .put("ageMs", it.ageMs).put("operatorName", it.operatorName).put("venueName", it.venueName)
        .put("infoElements", it.infoElements).put("risk", it.risk).put("distanceM", it.distanceM)

    fun toJson(w: List<WifiRec>, cams: List<CameraRec>): String = JSONObject().apply {
        put("version", 2); put("exportedAt", System.currentTimeMillis())
        put("wifi", JSONArray(w.map { wj(it) }))
        put("cameras", JSONArray(cams.map { JSONObject().put("name", it.name).put("ip", it.ip).put("port", it.port)
            .put("protocol", it.protocol).put("username", it.username).put("path", it.path) }))
    }.toString(2)

    fun toCsv(w: List<WifiRec>, fmt: (Long) -> String): String = buildString {
        appendLine("ssid,bssid,vendor,signal_dbm,percent,security,akm,cipher,pmf,wps,standard,band,frequency,channel,width,distance_m,risk,scan_time,lat,lon")
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        w.forEach { appendLine(listOf(q(it.ssid), it.bssid, q(it.vendor), it.level, it.percent, q(it.security), q(it.akm), q(it.cipher), it.pmf, q(it.wps),
            q(it.standard), band(it.frequency), it.frequency, it.channel, q(it.width), "%.1f".format(it.distanceM), q(it.risk), q(fmt(it.scanTime)), it.lat ?: "", it.lon ?: "").joinToString(",")) }
    }

    private fun JSONObject.s(k: String, d: String = "N/A") = if (has(k) && !isNull(k)) optString(k, d) else d

    /** Validates a backup and returns parsed data. Throws on an invalid file. */
    fun parse(s: String): Pair<List<WifiRec>, List<CameraRec>> {
        val o = JSONObject(s); require(o.has("version") && o.has("wifi")) { "Not a valid backup file" }
        val w = o.getJSONArray("wifi"); val c = o.optJSONArray("cameras") ?: JSONArray()
        val wl = (0 until w.length()).map { i -> val j = w.getJSONObject(i)
            WifiRec(ssid = j.getString("ssid"), bssid = j.getString("bssid"), level = j.getInt("level"), percent = j.getInt("percent"),
                security = j.getString("security"), frequency = j.getInt("frequency"), channel = j.getInt("channel"),
                width = j.s("width"), scanTime = j.getLong("scanTime"),
                lat = if (j.isNull("lat")) null else j.optDouble("lat"), lon = if (j.isNull("lon")) null else j.optDouble("lon"),
                permanent = j.optBoolean("permanent"), note = j.optString("note"),
                capabilities = j.s("capabilities"), vendor = j.s("vendor"), standard = j.s("standard"),
                centerFreq0 = j.optInt("centerFreq0"), centerFreq1 = j.optInt("centerFreq1"), wps = j.s("wps"), pmf = j.s("pmf"),
                akm = j.s("akm"), cipher = j.s("cipher"), isPasspoint = j.s("isPasspoint"), is80211mc = j.s("is80211mc"),
                ageMs = j.optLong("ageMs", -1), operatorName = j.s("operatorName"), venueName = j.s("venueName"),
                infoElements = j.s("infoElements"), risk = j.s("risk"), distanceM = j.optDouble("distanceM", -1.0)) }
        val cl = (0 until c.length()).map { i -> val j = c.getJSONObject(i)
            CameraRec(name = j.getString("name"), ip = j.getString("ip"), port = j.getInt("port"), protocol = j.getString("protocol"),
                username = j.optString("username"), path = j.optString("path")) }
        return wl to cl
    }
}
