package com.wcm.pro
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.BitmapFactory
import android.location.LocationManager
import android.net.ConnectivityManager
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.*
import java.net.*

// ---------- Location ----------
@SuppressLint("MissingPermission")
fun loc(c: Context): Pair<Double, Double>? = try {
    val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }?.let { it.latitude to it.longitude }
} catch (e: Exception) { null }

// ---------- Camera discovery on the connected subnet only ----------
val CAM_PORTS = listOf(554, 8554, 80, 8080, 8000, 81, 88)

suspend fun isOpen(ip: String, port: Int, ms: Int = 400) = withContext(Dispatchers.IO) {
    try { Socket().use { it.connect(InetSocketAddress(ip, port), ms) }; true } catch (e: Exception) { false } }

fun localPrefix(c: Context): String? {
    val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val ip = cm.getLinkProperties(cm.activeNetwork)?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.address?.hostAddress
    return ip?.substringBeforeLast('.')
}

/** Lists hosts on your connected subnet that expose RTSP or a camera-like HTTP page. No logins are tried. */
suspend fun discoverCameras(c: Context): List<CameraRec> = coroutineScope {
    val pre = localPrefix(c) ?: return@coroutineScope emptyList()
    (1..254).map { i -> async(Dispatchers.IO) {
        val h = "$pre.$i"
        val open = CAM_PORTS.filter { isOpen(h, it, 250) }
        when {
            open.isEmpty() -> null
            554 in open || 8554 in open -> { val p = if (554 in open) 554 else 8554; CameraRec(name = "RTSP $h", ip = h, port = p, protocol = "rtsp", status = "Online") }
            else -> { val p = open.first()
                val looksCam = try {
                    val k = URL("http://$h:$p/").openConnection() as HttpURLConnection; k.connectTimeout = 800; k.readTimeout = 800
                    val srv = (k.getHeaderField("Server") ?: "") + (k.getHeaderField("WWW-Authenticate") ?: "")
                    val body = try { k.inputStream.bufferedReader().readText().take(2000) } catch (e: Exception) { "" }
                    val s = (srv + body).lowercase()
                    listOf("camera", "ipcam", "webcam", "dvr", "nvr", "hikvision", "dahua", "mjpeg", "onvif", "streaming").any { it in s }
                } catch (e: Exception) { false }
                if (looksCam) CameraRec(name = "Web cam $h", ip = h, port = p, protocol = "http", status = "Online") else null }
        }
    } }.awaitAll().filterNotNull()
}

// ---------- Camera page ----------
@Composable fun CameraPage(dao: AppDao, scope: CoroutineScope) {
    val c = LocalContext.current
    val cams by dao.cameras().collectAsState(emptyList())
    var busy by remember { mutableStateOf(false) }
    var view by remember { mutableStateOf<CameraRec?>(null) }
    var editing by remember { mutableStateOf<CameraRec?>(null) }
    var adding by remember { mutableStateOf(false) }
    val current = view
    if (current != null) { Viewer(current) { view = null } } else Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Videocam, null, tint = Neon.Magenta, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(8.dp))
            Text("Cameras", style = MaterialTheme.typography.titleLarge, color = Neon.Text)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonButton(if (busy) "Searching..." else "Find cameras", Icons.Filled.Sensors, Neon.Cyan, Modifier.weight(1f), enabled = !busy) {
                busy = true
                scope.launch {
                    val found = discoverCameras(c)
                    val known = dao.allCameras().map { it.ip + ":" + it.port }.toSet()
                    found.filter { (it.ip + ":" + it.port) !in known }.forEach { dao.upsertCamera(it) }
                    busy = false
                }
            }
            NeonButton("Add", Icons.Filled.AddCircle, Neon.Violet, Modifier.weight(0.6f)) { editing = null; adding = true }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Neon.Cyan, trackColor = Neon.Card)
        Text("${cams.size} cameras on your network", color = Neon.Dim, style = MaterialTheme.typography.labelLarge)
        if (adding || editing != null) CamEditor(editing, dao, scope) { adding = false; editing = null }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(cams, key = { it.id }) { cam ->
                GlowCard(if (cam.status == "Online") Neon.Green else Neon.Dim) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (cam.protocol == "rtsp") Icons.Filled.Videocam else Icons.Filled.Public, null, tint = Neon.Cyan, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(cam.name, color = Neon.Text, style = MaterialTheme.typography.titleMedium)
                            Text("${cam.protocol}://${cam.ip}:${cam.port}${cam.path}", color = Neon.Dim, style = MaterialTheme.typography.bodySmall)
                        }
                        Chip(cam.status, if (cam.status == "Online") Neon.Green else Neon.Dim)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconTextButton("Watch", Icons.Filled.PlayCircle, Neon.Cyan) { view = cam }
                        IconTextButton("Test", Icons.Filled.Refresh, Neon.Amber) { scope.launch { dao.upsertCamera(cam.copy(status = if (isOpen(cam.ip, cam.port, 2000)) "Online" else "Offline")) } }
                        IconTextButton("Edit", Icons.Filled.Edit, Neon.Violet) { adding = false; editing = cam }
                        IconTextButton("Delete", Icons.Filled.Delete, Neon.Red) { scope.launch(Dispatchers.IO) { dao.deleteCamera(cam.id) } }
                    }
                }
            }
        }
    }
}

@Composable fun CamEditor(cam: CameraRec?, dao: AppDao, scope: CoroutineScope, done: () -> Unit) {
    var name by remember { mutableStateOf(cam?.name ?: "") }; var ip by remember { mutableStateOf(cam?.ip ?: "") }
    var port by remember { mutableStateOf((cam?.port ?: 554).toString()) }; var proto by remember { mutableStateOf(cam?.protocol ?: "rtsp") }
    var user by remember { mutableStateOf(cam?.username ?: "") }; var pass by remember { mutableStateOf(cam?.password ?: "") }
    var path by remember { mutableStateOf(cam?.path ?: "") }
    GlowCard(Neon.Violet) {
        NeonField(name, { name = it }, "Name", Icons.Filled.Badge); NeonField(ip, { ip = it }, "IP address", Icons.Filled.Router)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NeonField(port, { port = it }, "Port", Icons.Filled.Tag, Modifier.weight(1f)); NeonField(proto, { proto = it }, "rtsp / http", Icons.Filled.Link, Modifier.weight(1f)) }
        NeonField(path, { path = it }, "Path (/stream1 or /snapshot.jpg)", Icons.Filled.Link)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NeonField(user, { user = it }, "User", Icons.Filled.Person, Modifier.weight(1f))
            NeonField(pass, { pass = it }, "Password", Icons.Filled.Key, Modifier.weight(1f), password = true) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonButton("Save", Icons.Filled.Check, Neon.Green, Modifier.weight(1f)) {
                scope.launch(Dispatchers.IO) { dao.upsertCamera(CameraRec(cam?.id ?: 0, name.ifBlank { ip }, ip, port.toIntOrNull() ?: 554, proto, user, pass, path, cam?.status ?: "Unknown")) }; done() }
            NeonButton("Cancel", Icons.Filled.Close, Neon.Red, Modifier.weight(1f)) { done() }
        }
    }
}

// ---------- Viewer: play / pause / rewind / forward / zoom ----------
@Composable fun Viewer(c: CameraRec, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = if (c.path.isEmpty() || c.path.startsWith("/")) c.path else "/${c.path}"
    var zoom by remember { mutableStateOf(1f) }; var offX by remember { mutableStateOf(0f) }; var offY by remember { mutableStateOf(0f) }
    var playing by remember { mutableStateOf(true) }
    var bmp by remember { mutableStateOf<android.graphics.Bitmap?>(null) }; var err by remember { mutableStateOf("") }
    val isRtsp = c.protocol.equals("rtsp", true)
    val player = remember(c.id, c.ip, c.port, c.path) { if (!isRtsp) null else {
        val cred = if (c.username.isNotEmpty()) "${URLEncoder.encode(c.username, "UTF-8")}:${URLEncoder.encode(c.password, "UTF-8")}@" else ""
        ExoPlayer.Builder(ctx).setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build().apply { setMediaItem(MediaItem.fromUri("rtsp://$cred${c.ip}:${c.port}$p")); prepare(); playWhenReady = true } } }
    DisposableEffect(player) { onDispose { player?.release() } }
    if (!isRtsp) LaunchedEffect(c, playing) { while (isActive && playing) { withContext(Dispatchers.IO) { try {
        val k = URL("http://${c.ip}:${c.port}$p").openConnection() as HttpURLConnection; k.connectTimeout = 3000; k.readTimeout = 3000
        if (c.username.isNotEmpty()) k.setRequestProperty("Authorization", "Basic " + Base64.encodeToString("${c.username}:${c.password}".toByteArray(), Base64.NO_WRAP))
        if (k.responseCode == 200) { bmp = BitmapFactory.decodeStream(k.inputStream); err = "" } else err = "HTTP ${k.responseCode}"
    } catch (e: Exception) { err = e.message ?: "error" } }; delay(800) } }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(Icons.Filled.ArrowBack, Neon.Cyan) { onBack() }
            Spacer(Modifier.width(10.dp)); Text(c.name, color = Neon.Text, style = MaterialTheme.typography.titleLarge)
        }
        Box(Modifier.fillMaxWidth().height(300.dp).clipToBounds().background(Color.Black).border(1.dp, Neon.Cyan, RoundedCornerShape(16.dp))
            .pointerInput(Unit) { detectTransformGestures { _, pan, z, _ -> zoom = (zoom * z).coerceIn(1f, 6f); offX += pan.x; offY += pan.y } }) {
            val mod = Modifier.fillMaxSize().graphicsLayer(scaleX = zoom, scaleY = zoom, translationX = offX, translationY = offY)
            if (player != null) AndroidView(factory = { PlayerView(it).also { v -> v.player = player; v.useController = false } }, modifier = mod)
            else bmp?.let { Image(it.asImageBitmap(), null, mod) }
        }
        if (err.isNotEmpty()) Text(err, color = Neon.Red)
        Text("Zoom x${"%.1f".format(zoom)}", color = Neon.Dim)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(Icons.Filled.FastRewind, Neon.Violet) { player?.seekBack() }
            RoundIcon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, Neon.Cyan, big = true) {
                playing = !playing; player?.let { if (playing) it.play() else it.pause() } }
            RoundIcon(Icons.Filled.FastForward, Neon.Violet) { player?.seekForward() }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RoundIcon(Icons.Filled.ZoomOut, Neon.Amber) { zoom = (zoom - 0.5f).coerceAtLeast(1f); if (zoom == 1f) { offX = 0f; offY = 0f } }
            RoundIcon(Icons.Filled.CenterFocusStrong, Neon.Green) { zoom = 1f; offX = 0f; offY = 0f }
            RoundIcon(Icons.Filled.ZoomIn, Neon.Amber) { zoom = (zoom + 0.5f).coerceAtMost(6f) }
        }
        Text("Rewind and forward work only when the camera supplies a seekable recording. Live streams cannot be rewound.", color = Neon.Dim, style = MaterialTheme.typography.bodySmall)
    }
}
