package com.wcm.pro
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.BitmapFactory
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.*
import java.net.*
import java.security.MessageDigest

// ---------- PIN ----------
object Pin {
    private fun p(c: Context) = c.getSharedPreferences("sec", Context.MODE_PRIVATE)
    private fun h(salt: String, pin: String) = MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
    fun has(c: Context) = p(c).contains("hash")
    fun set(c: Context, pin: String) { val s = java.util.UUID.randomUUID().toString(); p(c).edit().putString("salt", s).putString("hash", h(s, pin)).apply() }
    fun check(c: Context, pin: String) = h(p(c).getString("salt", "")!!, pin) == p(c).getString("hash", "")
    fun clear(c: Context) = p(c).edit().clear().apply()
    const val MAX = 30
    fun fails(c: Context) = p(c).getInt("fails", 0)
    fun addFail(c: Context): Int { val n = fails(c) + 1; p(c).edit().putInt("fails", n).commit(); return n }
    fun resetFails(c: Context) = p(c).edit().putInt("fails", 0).apply()
    /** Wipes all app data (database, prefs) and opens the system uninstall screen. */
    fun wipeAndUninstall(c: Context) {
        try { AppDb.get(c).close() } catch (e: Exception) {}
        c.deleteDatabase("wcm.db")
        try { androidx.work.WorkManager.getInstance(c).cancelAllWork() } catch (e: Exception) {}
        p(c).edit().clear().commit()
        val i = android.content.Intent(android.content.Intent.ACTION_DELETE, android.net.Uri.parse("package:" + c.packageName))
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }
}

@Composable fun Gate() {
    val c = LocalContext.current; var ok by remember { mutableStateOf(!Pin.has(c)) }; var t by remember { mutableStateOf("") }
    var left by remember { mutableStateOf(Pin.MAX - Pin.fails(c)) }
    if (ok) App() else Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center) {
        Text("Enter PIN", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(t, { t = it.filter(Char::isDigit) }, visualTransformation = PasswordVisualTransformation(), isError = left < Pin.MAX, singleLine = true)
        if (left < Pin.MAX) Text("Wrong PIN. Attempts left: $left. At 0 all app data is erased and the app is uninstalled.")
        Button(onClick = {
            if (Pin.check(c, t)) { Pin.resetFails(c); ok = true }
            else { val n = Pin.addFail(c); left = Pin.MAX - n; t = ""; if (n >= Pin.MAX) Pin.wipeAndUninstall(c) }
        }) { Text("Unlock") }
    }
}

@Composable fun SettingsScreen() {
    val c = LocalContext.current; var pin by remember { mutableStateOf("") }; var m by remember { mutableStateOf(if (Pin.has(c)) "PIN is ON" else "PIN is OFF") }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge); Text(m)
        OutlinedTextField(pin, { pin = it.filter(Char::isDigit) }, label = { Text("New PIN (4+ digits)") }, visualTransformation = PasswordVisualTransformation())
        Button(onClick = { if (pin.length >= 4) { Pin.set(c, pin); Pin.resetFails(c); m = "PIN saved"; pin = "" } else m = "PIN too short" }) { Text("Set / Change PIN") }
        Button(onClick = { Pin.clear(c); m = "PIN removed" }) { Text("Remove PIN") }
        Text("Temporary records auto-delete after 30 days. Permanent records are never auto-deleted.")
    }
}

// ---------- Location ----------
@SuppressLint("MissingPermission")
fun loc(c: Context): Pair<Double, Double>? = try {
    val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }?.let { it.latitude to it.longitude }
} catch (e: Exception) { null }

// ---------- History ----------
@Composable fun HistoryScreen(dao: AppDao, openTime: Long?, onOpen: (Long?) -> Unit) {
    val h by dao.history().collectAsState(emptyList())
    if (openTime == null) LazyColumn { items(h) { Card(Modifier.fillMaxWidth().padding(2.dp).clickable { onOpen(it.t) }) { Text("${fmt(it.t)} — ${it.n} networks (tap to open)", Modifier.padding(10.dp)) } } }
    else { val l by dao.byScan(openTime).collectAsState(emptyList()); Column { TextButton(onClick = { onOpen(null) }) { Text("← Back") }; WifiList(l, null, null) } }
}

// ---------- Network analysis (own / authorized networks only) ----------
suspend fun openPorts(ip: String, ports: List<Int>, ms: Int): List<Int> {
    val r = mutableListOf<Int>()
    for (p in ports) if (isOpen(ip, p, ms)) r += p
    return r
}

/** Reads the first line a service volunteers (banner) or the HTTP Server header. Only on hosts you are authorized to test. */
suspend fun banner(ip: String, port: Int): String = withContext(Dispatchers.IO) {
    try {
        Socket().use { s ->
            s.connect(InetSocketAddress(ip, port), 800); s.soTimeout = 1200
            if (port in listOf(80, 8080, 8000)) {
                s.getOutputStream().write("HEAD / HTTP/1.0\r\n\r\n".toByteArray())
                val lines = s.getInputStream().bufferedReader().readLines().take(12)
                lines.firstOrNull { it.startsWith("Server:", true) } ?: lines.firstOrNull() ?: "no banner"
            } else s.getInputStream().bufferedReader().readLine() ?: "no banner"
        }
    } catch (e: Exception) { "no banner" }
}

val PORTS = mapOf(21 to "FTP", 22 to "SSH", 23 to "Telnet", 53 to "DNS", 80 to "HTTP", 443 to "HTTPS", 554 to "RTSP", 8080 to "HTTP-alt", 8554 to "RTSP-alt", 8000 to "HTTP-alt")
suspend fun isOpen(ip: String, port: Int, ms: Int = 400) = withContext(Dispatchers.IO) {
    try { Socket().use { it.connect(InetSocketAddress(ip, port), ms) }; true } catch (e: Exception) { false } }

@Suppress("DEPRECATION")
fun netInfo(c: Context): String {
    val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val n = cm.activeNetwork ?: return "Connection: not connected"
    val lp = cm.getLinkProperties(n); val nc = cm.getNetworkCapabilities(n)
    val a = lp?.linkAddresses?.firstOrNull { it.address is Inet4Address }
    val gw = lp?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress
    val d = (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).dhcpInfo
    fun ip(i: Int) = "${i and 255}.${i shr 8 and 255}.${i shr 16 and 255}.${i shr 24 and 255}"
    return "Connection: connected (${if (nc?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) "Wi-Fi" else "Other"})\n" +
        "Internet validated: ${nc?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ?: "N/A"}\n" +
        "Local IP: ${a?.address?.hostAddress ?: "N/A"}/${a?.prefixLength ?: "N/A"}\nGateway: ${gw ?: "N/A"}\n" +
        "DNS: ${lp?.dnsServers?.joinToString { it.hostAddress ?: "" }?.ifBlank { "N/A" } ?: "N/A"}\n" +
        "DHCP server: ${if (d != null && d.serverAddress != 0) ip(d.serverAddress) else "N/A"}"
}

@Composable fun NetScreen(last: List<WifiRec>) {
    val c = LocalContext.current; val scope = rememberCoroutineScope()
    var info by remember { mutableStateOf(netInfo(c)) }; var out by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }; var auth by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(info); Button(onClick = { info = netInfo(c) }) { Text("Refresh") }
        Button(onClick = { scope.launch { val t = System.nanoTime(); val ok = isOpen("1.1.1.1", 53, 2000); val ms = (System.nanoTime() - t) / 1_000_000
            val dns = withContext(Dispatchers.IO) { try { InetAddress.getByName("example.com").hostAddress } catch (e: Exception) { null } }
            out = "Latency: ${if (ok) "$ms ms" else "N/A (unreachable)"}\nDNS resolve example.com: ${dns ?: "FAILED"}" } }) { Text("Latency + DNS test") }
        Button(onClick = { val weak = last.filter { it.security.startsWith("Open") || it.security.startsWith("WEP") || it.security == "WPA" }
            val q = last.count { it.percent < 40 }
            out = "Security review (${last.size} scanned): ${weak.size} weak/open\n" + weak.joinToString("\n") { "• ${it.ssid}: ${it.security}" } +
                "\nSignal quality: $q networks below 40%\nChannel congestion: ${Scanner.congestion(last)}" }) { Text("Security / channel / signal review (last scan)") }
        Spacer(Modifier.height(8.dp))
        Row { Checkbox(checked = auth, onCheckedChange = { auth = it }); Text("I am authorized to test this network/host") }
        OutlinedTextField(host, { host = it }, label = { Text("Host IP") })
        Button(enabled = auth && host.isNotBlank(), onClick = { scope.launch { out = "Scanning $host…"
            val r = PORTS.map { (p, s) -> async { if (isOpen(host, p)) "$p/$s open" else null } }.awaitAll().filterNotNull()
            val withBanner = r.map { line -> val port = line.substringBefore("/").toInt(); "$line  -> ${banner(host, port)}" }
            out = "Port inspection $host:\n" + withBanner.ifEmpty { listOf("no common ports open") }.joinToString("\n") } }) { Text("Port inspection + service banners") }
        Button(enabled = auth, onClick = { scope.launch { out = "Discovering…"
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val ip = cm.getLinkProperties(cm.activeNetwork)?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.address?.hostAddress
            if (ip == null) { out = "Not connected"; return@launch }
            val pre = ip.substringBeforeLast('.')
            val found = (1..254).map { i -> async { val h = "$pre.$i"; val p = openPorts(h, listOf(80, 554, 22, 443), 250); if (p.isEmpty()) null else "$h  ${p.joinToString { PORTS[it] ?: "$it" }}" } }.awaitAll().filterNotNull()
            out = "Devices (own subnet):\n" + found.joinToString("\n") } }) { Text("Device discovery (subnet)") }
        Text(out)
    }
}

// ---------- Cameras ----------
@Composable fun CameraScreen2(dao: AppDao, scope: CoroutineScope, onView: (CameraRec) -> Unit) {
    val cams by dao.cameras().collectAsState(emptyList())
    var id by remember { mutableStateOf(0L) }; var name by remember { mutableStateOf("") }; var ip by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("554") }; var proto by remember { mutableStateOf("rtsp") }
    var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }; var path by remember { mutableStateOf("") }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item { Column {
            OutlinedTextField(name, { name = it }, label = { Text("Name") }); OutlinedTextField(ip, { ip = it }, label = { Text("IP") })
            Row { OutlinedTextField(port, { port = it }, label = { Text("Port") }, modifier = Modifier.weight(1f))
                OutlinedTextField(proto, { proto = it }, label = { Text("rtsp / http") }, modifier = Modifier.weight(1f)) }
            OutlinedTextField(path, { path = it }, label = { Text("Path (e.g. /stream1 or /snapshot.jpg)") })
            Row { OutlinedTextField(user, { user = it }, label = { Text("User") }, modifier = Modifier.weight(1f))
                OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.weight(1f)) }
            Button(onClick = { scope.launch(Dispatchers.IO) { dao.upsertCamera(CameraRec(id, name, ip, port.toIntOrNull() ?: 554, proto, user, pass, path)); id = 0; name = ""; ip = ""; user = ""; pass = ""; path = "" } }) { Text(if (id == 0L) "Add camera" else "Save changes") }
        } }
        items(cams) { c -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(8.dp)) {
            Text("${c.name} — ${c.protocol}://${c.ip}:${c.port}${c.path} [${c.status}]")
            Row { TextButton(onClick = { scope.launch { val s = if (isOpen(c.ip, c.port, 2000)) "Online" else "Offline"; dao.upsertCamera(c.copy(status = s)) } }) { Text("Test") }
                TextButton(onClick = { onView(c) }) { Text("View") }
                TextButton(onClick = { id = c.id; name = c.name; ip = c.ip; port = "${c.port}"; proto = c.protocol; user = c.username; pass = c.password; path = c.path }) { Text("Edit") }
                TextButton(onClick = { scope.launch(Dispatchers.IO) { dao.deleteCamera(c.id) } }) { Text("Delete") } } } } }
    }
}

@Composable fun ViewerScreen(c: CameraRec?) {
    if (c == null) { Text("Pick a camera from Cameras → View"); return }
    val ctx = LocalContext.current; val p = if (c.path.isEmpty() || c.path.startsWith("/")) c.path else "/${c.path}"
    if (c.protocol.equals("rtsp", true)) {
        val cred = if (c.username.isNotEmpty()) "${URLEncoder.encode(c.username, "UTF-8")}:${URLEncoder.encode(c.password, "UTF-8")}@" else ""
        val player = remember(c.id, c.ip, c.port, c.path) { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri("rtsp://$cred${c.ip}:${c.port}$p")); prepare(); playWhenReady = true } }
        DisposableEffect(player) { onDispose { player.release() } }
        AndroidView(factory = { PlayerView(it).also { v -> v.player = player } }, modifier = Modifier.fillMaxWidth().height(300.dp))
    } else { // HTTP snapshot / MJPEG-frame polling with Basic auth (the camera's own credentials)
        var bmp by remember { mutableStateOf<android.graphics.Bitmap?>(null) }; var err by remember { mutableStateOf("") }
        LaunchedEffect(c) { while (isActive) { withContext(Dispatchers.IO) { try {
            val k = URL("http://${c.ip}:${c.port}$p").openConnection() as HttpURLConnection; k.connectTimeout = 3000; k.readTimeout = 3000
            if (c.username.isNotEmpty()) k.setRequestProperty("Authorization", "Basic " + Base64.encodeToString("${c.username}:${c.password}".toByteArray(), Base64.NO_WRAP))
            if (k.responseCode == 200) { bmp = BitmapFactory.decodeStream(k.inputStream); err = "" } else err = "HTTP ${k.responseCode}"
        } catch (e: Exception) { err = e.message ?: "error" } }; delay(1000) } }
        Column { bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth()) }; if (err.isNotEmpty()) Text(err) }
    }
}


// ---------- Access point analyzer: everything we know about one BSSID ----------
@Composable fun ApAnalyzer(dao: AppDao) {
    var q by remember { mutableStateOf("") }
    val seen by dao.wifi(false, "").collectAsState(emptyList())
    val saved by dao.wifi(true, "").collectAsState(emptyList())
    val latest = (seen + saved).groupBy { it.bssid }.map { (_, v) -> v.maxByOrNull { it.scanTime }!! }
        .filter { q.isBlank() || it.ssid.contains(q, true) || it.bssid.contains(q, true) }.sortedByDescending { it.level }
    var pick by remember { mutableStateOf<String?>(null) }
    if (pick == null) {
        OutlinedTextField(q, { q = it }, label = { Text("Filter access points") }, modifier = Modifier.fillMaxWidth())
        Text("${latest.size} unique access points. Tap one to analyze.")
        LazyColumn { items(latest) { w -> Card(Modifier.fillMaxWidth().padding(2.dp)) {
            TextButton(onClick = { pick = w.bssid }) { Text("${w.ssid}  |  ${w.bssid}  |  ${w.level} dBm  |  ${w.security}") } } } }
    } else {
        val hist by dao.byBssid(pick!!).collectAsState(emptyList())
        TextButton(onClick = { pick = null }) { Text("< Back") }
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val n = hist.firstOrNull()
            if (n != null) {
                Text(Scanner.report(n, ::fmt))
                Text("Sightings: ${hist.size}")
                Text("First seen: ${fmt(hist.last().scanTime)}   Last seen: ${fmt(n.scanTime)}")
                Text("Signal min / avg / max: ${hist.minOf { it.level }} / ${hist.map { it.level }.average().toInt()} / ${hist.maxOf { it.level }} dBm")
                val ch = hist.map { it.channel }.distinct(); val sec = hist.map { it.security }.distinct()
                Text("Channels seen: ${ch.joinToString()}")
                if (sec.size > 1) Text("WARNING: security changed over time (${sec.joinToString()}). Could be a reconfigured AP or a spoofed one.")
                val same = (seen + saved).filter { it.ssid == n.ssid && it.bssid != n.bssid && !it.ssid.startsWith("N/A") }.map { it.bssid }.distinct()
                if (same.isNotEmpty()) Text("Other BSSIDs with the same SSID (mesh/extender or possible evil twin): ${same.joinToString()}")
                Text("Signal history (newest first):")
                hist.take(40).forEach { Text("${fmt(it.scanTime)}  ${it.level} dBm  ch${it.channel}  ${it.security}") }
            }
        }
    }
}
