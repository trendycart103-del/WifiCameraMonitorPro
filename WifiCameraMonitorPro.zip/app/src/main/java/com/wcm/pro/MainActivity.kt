package com.wcm.pro
import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        CleanupWorker.schedule(this)
        setContent { MaterialTheme { Gate() } }
    }
}

fun fmt(t: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(t))

enum class ExportKind { ALL, WIFI, CAMERAS, HISTORY, SELECTED, CSV, REPORT }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf("Dashboard") }
    var last by remember { mutableStateOf(listOf<WifiRec>()) }
    var msg by remember { mutableStateOf("") }
    var viewCam by remember { mutableStateOf<CameraRec?>(null) }
    var pendingKind by remember { mutableStateOf(ExportKind.ALL) }
    var pendingIds by remember { mutableStateOf(listOf<Long>()) }
    var replace by remember { mutableStateOf(false) }
    var openTime by remember { mutableStateOf<Long?>(null) }
    val tempN by dao.count(false).collectAsState(0)
    val permN by dao.count(true).collectAsState(0)

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { u: Uri? ->
        if (u != null) scope.launch(Dispatchers.IO) {
            msg = try {
                val text = when (pendingKind) {
                    ExportKind.ALL -> Scanner.toJson(dao.allWifi(), dao.allCameras())
                    ExportKind.WIFI -> Scanner.toJson(dao.permWifi(), emptyList())
                    ExportKind.CAMERAS -> Scanner.toJson(emptyList(), dao.allCameras())
                    ExportKind.HISTORY -> Scanner.toJson(dao.allWifi().filter { !it.permanent }, emptyList())
                    ExportKind.SELECTED -> Scanner.toJson(dao.byIds(pendingIds), emptyList())
                    ExportKind.CSV -> Scanner.toCsv(dao.allWifi(), ::fmt)
                    ExportKind.REPORT -> dao.allWifi().joinToString("\n----------------\n") { Scanner.report(it, ::fmt) }
                }
                ctx.contentResolver.openOutputStream(u)?.use { it.write(text.toByteArray()) }
                "Exported successfully"
            } catch (e: Exception) { "Export failed: ${e.message}" }
        }
    }
    fun doExport(kind: ExportKind, name: String, ids: List<Long> = emptyList()) {
        pendingKind = kind; pendingIds = ids; export.launch(name)
    }

    fun restoreFrom(u: Uri) { scope.launch(Dispatchers.IO) { msg = try {
        val (w, c) = Scanner.parse(ctx.contentResolver.openInputStream(u)!!.bufferedReader().readText())  // validates first
        if (replace) { dao.clearWifi(); dao.clearCameras() }
        dao.insertWifi(w.map { r -> r.copy(id = 0) }); c.forEach { cam -> dao.upsertCamera(cam.copy(id = 0)) }
        "Imported ${w.size} Wi-Fi, ${c.size} cameras" } catch (e: Exception) { "Invalid backup: ${e.message}" } } }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> u?.let { restoreFrom(it) } }

    Scaffold(
        topBar = { TopAppBar(title = { Text("WiFi & Camera Monitor Pro") }) },
        bottomBar = {
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                listOf("Dashboard", "Scanner", "Analyzer", "Network", "Temp", "Saved", "History", "Cameras", "Viewer", "Settings").forEach {
                    TextButton(onClick = { screen = it; openTime = null }) {
                        Text(it, color = if (screen == it) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(12.dp)) {
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.primary)
            when (screen) {
                "Dashboard" -> Dashboard(last, tempN, permN,
                    onBackup = { doExport(ExportKind.ALL, "wcm-backup.json") },
                    onMerge = { replace = false; import.launch(arrayOf("*/*")) },
                    onReplace = { replace = true; import.launch(arrayOf("*/*")) },
                    onWifi = { doExport(ExportKind.WIFI, "wifi-database.json") },
                    onCams = { doExport(ExportKind.CAMERAS, "camera-database.json") },
                    onHist = { doExport(ExportKind.HISTORY, "scan-history.json") },
                    onCsv = { doExport(ExportKind.CSV, "wifi-data.csv") },
                    onReport = { doExport(ExportKind.REPORT, "wifi-report.txt") })
                "Scanner" -> Column {
                    Button(onClick = {
                        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
                        if (android.os.Build.VERSION.SDK_INT >= 33) p += "android.permission.NEARBY_WIFI_DEVICES"
                        perm.launch(p.toTypedArray())
                        scope.launch(Dispatchers.IO) {
                            val l = loc(ctx)
                            val r = Scanner.scan(ctx, l?.first, l?.second)
                            last = r
                            dao.insertWifi(r)
                            msg = if (r.isEmpty()) "No results. Grant location permission and turn Wi-Fi and Location on." else "Found ${r.size} networks"
                        }
                    }) { Text("Scan now") }
                    WifiList(last, null, null)
                }
                "Analyzer" -> ApAnalyzer(dao)
                "Network" -> NetScreen(last)
                "Temp", "Saved" -> {
                    val isP = screen == "Saved"
                    var q by remember { mutableStateOf("") }
                    val list by dao.wifi(isP, q).collectAsState(emptyList())
                    val sel = remember { mutableStateListOf<Long>() }
                    OutlinedTextField(q, { q = it }, label = { Text("Search SSID, BSSID, vendor, security") }, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { sel.clear(); sel.addAll(list.map { it.id }) }) { Text("Select all") }
                        Button(onClick = { sel.clear() }) { Text("Deselect all") }
                        if (!isP) Button(onClick = {
                            scope.launch(Dispatchers.IO) {
                                var n = 0
                                dao.byIds(sel.toList()).forEach { w ->
                                    val e = dao.savedByBssid(w.bssid)
                                    if (e == null) dao.insertWifi(listOf(w.copy(id = 0, permanent = true)))
                                    else dao.updateWifi(w.copy(id = e.id, permanent = true, note = e.note))
                                    n++
                                }
                                msg = "Saved $n to permanent database"
                                sel.clear()
                            }
                        }) { Text("Save selected") }
                        Button(enabled = sel.isNotEmpty(), onClick = { doExport(ExportKind.SELECTED, "wifi-selected.json", sel.toList()) }) { Text("Export selected") }
                    }
                    WifiList(list, sel, { w -> scope.launch(Dispatchers.IO) { dao.deleteWifi(w.id) } }, if (isP) { w, n -> scope.launch(Dispatchers.IO) { dao.updateWifi(w.copy(note = n)); msg = "Note saved" } } else null)
                }
                "History" -> HistoryScreen(dao, openTime) { openTime = it }
                "Cameras" -> CameraScreen2(dao, scope) { viewCam = it; screen = "Viewer" }
                "Viewer" -> ViewerScreen(viewCam)
                "Settings" -> SettingsScreen()
            }
        }
    }
}

@Composable
fun Dashboard(last: List<WifiRec>, tempN: Int, permN: Int,
              onBackup: () -> Unit, onMerge: () -> Unit, onReplace: () -> Unit,
              onWifi: () -> Unit, onCams: () -> Unit, onHist: () -> Unit, onCsv: () -> Unit, onReport: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text("Network statistics", style = MaterialTheme.typography.titleMedium)
            Text("Last scan: ${last.size} networks")
            Text("Open / WEP / weak (grade F): ${last.count { Scanner.grade(it) == "F" }}")
            Text("WPA3 networks: ${last.count { it.security.contains("WPA3") }}")
            Text("2.4 GHz: ${last.count { it.frequency in 2400..2500 }}   5 GHz: ${last.count { it.frequency in 4900..5900 }}   6 GHz: ${last.count { it.frequency in 5925..7125 }}")
            Text("Strongest: ${last.maxByOrNull { it.level }?.let { "${it.ssid} (${it.level} dBm)" } ?: "N/A"}")
            Text("Busiest channels: ${Scanner.congestion(last).entries.sortedByDescending { it.value }.take(3).joinToString { "ch${it.key} x${it.value}" }.ifBlank { "N/A" }}")
            Text("Suggested 2.4 GHz channel: ${if (last.any { it.frequency in 2400..2500 }) Scanner.bestChannel24(last).toString() else "N/A"}")
            Text("Temporary records: $tempN   Permanent records: $permN")
        } }
        Text("Backup and restore", style = MaterialTheme.typography.titleMedium)
        Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Text("Export all data (JSON)") }
        Button(onClick = onWifi, modifier = Modifier.fillMaxWidth()) { Text("Export Wi-Fi database") }
        Button(onClick = onCams, modifier = Modifier.fillMaxWidth()) { Text("Export camera database") }
        Button(onClick = onHist, modifier = Modifier.fillMaxWidth()) { Text("Export scan history") }
        Button(onClick = onCsv, modifier = Modifier.fillMaxWidth()) { Text("Export all Wi-Fi as CSV") }
        Button(onClick = onReport, modifier = Modifier.fillMaxWidth()) { Text("Export full text report") }
        Button(onClick = onMerge, modifier = Modifier.fillMaxWidth()) { Text("Import / restore (merge)") }
        Button(onClick = onReplace, modifier = Modifier.fillMaxWidth()) { Text("Import / restore (replace all)") }
    }
}

@Composable
fun WifiList(list: List<WifiRec>, sel: MutableList<Long>?, onDelete: ((WifiRec) -> Unit)?, onNote: ((WifiRec, String) -> Unit)? = null) {
    val ctx = LocalContext.current
    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(list, key = { "${it.id}-${it.bssid}-${it.scanTime}" }) { w ->
            var open by remember { mutableStateOf(false) }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Row {
                        if (sel != null) Checkbox(checked = w.id in sel, onCheckedChange = { c -> if (c) sel.add(w.id) else sel.remove(w.id) })
                        Text(w.ssid, style = MaterialTheme.typography.titleMedium)
                    }
                    Text("SSID: ${w.ssid}\nBSSID: ${w.bssid}\nSignal: ${w.level} dBm (${w.percent}%)\nSecurity: ${w.security}  [grade ${Scanner.grade(w)}]\nFrequency: ${w.frequency} MHz\nChannel: ${w.channel}\nScan Time: ${fmt(w.scanTime)}")
                    Row {
                        TextButton(onClick = { open = !open }) { Text(if (open) "Hide details" else "Details") }
                        TextButton(onClick = {
                            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Scanner.report(w, ::fmt))
                            ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }) { Text("Share") }
                        if (onDelete != null) TextButton(onClick = { onDelete(w) }) { Text("Delete") }
                    }
                    if (open) Text(Scanner.report(w, ::fmt))
                    if (open && onNote != null) {
                        var note by remember { mutableStateOf(w.note) }
                        OutlinedTextField(note, { note = it }, label = { Text("Note (editable)") }, modifier = Modifier.fillMaxWidth())
                        TextButton(onClick = { onNote(w, note) }) { Text("Save note") }
                    }
                }
            }
        }
    }
}
