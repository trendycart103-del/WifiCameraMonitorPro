package com.wcm.pro
import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        CleanupWorker.schedule(this)
        setContent { ProTheme { App() } }
    }
}

fun fmt(t: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(t))

@Composable fun App() {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    LaunchedEffect(Unit) {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (android.os.Build.VERSION.SDK_INT >= 33) p += "android.permission.NEARBY_WIFI_DEVICES"
        perm.launch(p.toTypedArray())
    }
    Scaffold(containerColor = Neon.Bg,
        bottomBar = {
            NavigationBar(containerColor = Neon.Bg2) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Filled.Wifi, null) }, label = { Text("Scanner") },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Neon.Bg, indicatorColor = Neon.Cyan, selectedTextColor = Neon.Cyan, unselectedIconColor = Neon.Dim, unselectedTextColor = Neon.Dim))
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Filled.Videocam, null) }, label = { Text("Cameras") },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Neon.Bg, indicatorColor = Neon.Magenta, selectedTextColor = Neon.Magenta, unselectedIconColor = Neon.Dim, unselectedTextColor = Neon.Dim))
            }
        }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Neon.bgBrush)) {
            if (tab == 0) ScannerPage(dao) else CameraPage(dao, scope)
        }
    }
}

@Composable fun ScannerPage(dao: AppDao) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var autoScan by remember { mutableStateOf(true) }
    var msg by remember { mutableStateOf("") }
    var showSaved by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    val temp by dao.wifi(false, q).collectAsState(emptyList())
    val saved by dao.wifi(true, q).collectAsState(emptyList())
    val tempN by dao.count(false).collectAsState(0); val permN by dao.count(true).collectAsState(0)

    suspend fun doScan() {
        val l = loc(ctx)
        val r = Scanner.scan(ctx, l?.first, l?.second)
        if (r.isNotEmpty()) { dao.insertWifi(r); dao.trimTemp(); msg = "Found ${r.size} networks" }
        else msg = "No results. Allow location and turn Wi-Fi and Location on."
    }
    // auto temporary save: while auto-scan is on, scan every 12 seconds (Android throttles scans)
    LaunchedEffect(autoScan) { while (isActive && autoScan) { withContext(Dispatchers.IO) { doScan() }; delay(12000) } }

    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Wifi, null, tint = Neon.Cyan, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(8.dp))
            Text("WiFi Scanner", style = MaterialTheme.typography.titleLarge, color = Neon.Text, modifier = Modifier.weight(1f))
            Chip(if (autoScan) "AUTO ON" else "AUTO OFF", if (autoScan) Neon.Green else Neon.Dim)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonButton("Scan now", Icons.Filled.Sensors, Neon.Cyan, Modifier.weight(1f)) { scope.launch(Dispatchers.IO) { doScan() } }
            NeonButton(if (autoScan) "Pause auto" else "Start auto", if (autoScan) Icons.Filled.PauseCircle else Icons.Filled.PlayCircle, Neon.Violet, Modifier.weight(1f)) { autoScan = !autoScan }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonButton("Temporary ($tempN)", Icons.Filled.History, if (!showSaved) Neon.Magenta else Neon.Dim, Modifier.weight(1f)) { showSaved = false }
            NeonButton("Saved ($permN)", Icons.Filled.Bookmarks, if (showSaved) Neon.Amber else Neon.Dim, Modifier.weight(1f)) { showSaved = true }
        }
        NeonField(q, { q = it }, "Search SSID, BSSID, vendor, security", Icons.Filled.Search)
        if (msg.isNotEmpty()) Text(msg, color = Neon.Cyan, fontSize = 12.sp)
        val list = if (showSaved) saved else temp
        // newest sighting per BSSID keeps the list readable
        val shown = list.groupBy { it.bssid }.map { (_, v) -> v.maxByOrNull { it.scanTime }!! }.sortedByDescending { it.level }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(shown, key = { "${it.id}-${it.bssid}" }) { w -> WifiCard(w, showSaved, dao, scope) { msg = it } }
        }
    }
}

@Composable fun WifiCard(w: WifiRec, isSaved: Boolean, dao: AppDao, scope: kotlinx.coroutines.CoroutineScope, say: (String) -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val g = Scanner.grade(w)
    GlowCard(signalColor(w.percent)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(when { w.percent >= 70 -> Icons.Filled.SignalWifi4Bar; w.percent >= 45 -> Icons.Filled.NetworkWifi3Bar; else -> Icons.Filled.NetworkWifi1Bar }, null, tint = signalColor(w.percent), modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(w.ssid, color = Neon.Text, style = MaterialTheme.typography.titleMedium)
                Text(w.bssid, color = Neon.Dim, style = MaterialTheme.typography.bodySmall)
            }
            Chip("Grade $g", gradeColor(g))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("${w.level} dBm", signalColor(w.percent)); Chip(Scanner.band(w.frequency), Neon.Violet); Chip("CH ${w.channel}", Neon.Cyan)
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Lock, null, tint = Neon.Amber, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(w.security, color = Neon.Text, fontSize = 13.sp) }
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Schedule, null, tint = Neon.Dim, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(fmt(w.scanTime), color = Neon.Dim, fontSize = 12.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            IconTextButton(if (open) "Hide" else "All data", if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, Neon.Cyan) { open = !open }
            if (!isSaved) IconTextButton("Save", Icons.Filled.BookmarkBorder, Neon.Green) {
                scope.launch(Dispatchers.IO) {
                    val e = dao.savedByBssid(w.bssid)
                    if (e == null) dao.insertWifi(listOf(w.copy(id = 0, permanent = true))) else dao.updateWifi(w.copy(id = e.id, permanent = true, note = e.note))
                    say("Saved ${w.ssid}") }
            }
            IconTextButton("Share", Icons.Filled.Share, Neon.Violet) {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Scanner.report(w, ::fmt))
                ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            IconTextButton("Delete", Icons.Filled.Delete, Neon.Red) { scope.launch(Dispatchers.IO) { dao.deleteWifi(w.id) } }
        }
        if (open) {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Neon.Bg).padding(10.dp)) {
                Text(Scanner.report(w, ::fmt), color = Neon.Text, style = MaterialTheme.typography.bodySmall) }
            if (isSaved) {
                var note by remember { mutableStateOf(w.note) }
                NeonField(note, { note = it }, "Your note", Icons.Filled.Edit)
                IconTextButton("Save note", Icons.Filled.Check, Neon.Green) { scope.launch(Dispatchers.IO) { dao.updateWifi(w.copy(note = note)); say("Note saved") } }
            }
        }
    }
}
